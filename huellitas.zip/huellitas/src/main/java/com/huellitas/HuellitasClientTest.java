package com.huellitas;

import com.huellitas.grpc.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * Cliente gRPC de pruebas de integración.
 * Ejecutar DESPUÉS de iniciar HuellitasServer.
 */
public class HuellitasClientTest {

    private static final Logger LOG = Logger.getLogger(HuellitasClientTest.class.getName());

    private final ManagedChannel                        channel;
    private final OrdenServiceGrpc.OrdenServiceBlockingStub stub;

    public HuellitasClientTest(String host, int port) {
        channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();
        stub    = OrdenServiceGrpc.newBlockingStub(channel);
    }

    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }

    // ── CASO 1: Orden válida ─────────────────────────────────────────────────
    private void casoOrdenValida() {
        separador("CASO 1 — Orden válida (esperado: APROBADA)");
        LOG.info("Cliente CLI-001 | Producto PRD-001 (Vacuna Antirrábica Canina $250) | Cantidad: 2");

        OrdenRequest req = OrdenRequest.newBuilder()
                .setIdCliente("CLI-001").setIdProducto("PRD-001").setCantidad(2).build();
        try {
            OrdenResponse r = stub.procesarOrden(req);
            imprimirRespuesta(r);
        } catch (StatusRuntimeException e) {
            LOG.warning("Error gRPC: " + e.getStatus());
        }
    }

    // ── CASO 2: Sobregiro de stock ────────────────────────────────────────────
    private void casoSobreGiroStock() {
        separador("CASO 2 — Sobregiro de stock (esperado: RECHAZADA)");
        LOG.info("Cliente CLI-004 | Producto PRD-007 (Vacuna Leucemia, stock=70) | Cantidad: 999");

        OrdenRequest req = OrdenRequest.newBuilder()
                .setIdCliente("CLI-004").setIdProducto("PRD-007").setCantidad(999).build();
        try {
            OrdenResponse r = stub.procesarOrden(req);
            imprimirRespuesta(r);
        } catch (StatusRuntimeException e) {
            LOG.warning("Error gRPC: " + e.getStatus());
        }
    }

    // ── CASO 3: Datos inválidos (ID inexistente) ──────────────────────────────
    private void casoDatosInvalidos() {
        separador("CASO 3 — Datos inválidos (esperado: INVALID_ARGUMENT)");
        LOG.info("Cliente CLI-999 (no existe) | Producto PRD-001 | Cantidad: 1");

        OrdenRequest req = OrdenRequest.newBuilder()
                .setIdCliente("CLI-999").setIdProducto("PRD-001").setCantidad(1).build();
        try {
            OrdenResponse r = stub.procesarOrden(req);
            imprimirRespuesta(r);
        } catch (StatusRuntimeException e) {
            LOG.info("EXCEPCIÓN CONTROLADA POR EL MIDDLEWARE:");
            LOG.info("  Código gRPC : " + e.getStatus().getCode());
            LOG.info("  Descripción : " + e.getStatus().getDescription());
        }
    }

    // ── BONUS: Orden con descuento (compra > $1,500) ─────────────────────────
    private void casoConDescuento() {
        separador("BONUS — Compra > $1,500 (esperado: APROBADA con 10% descuento)");
        LOG.info("Cliente CLI-003 | Producto PRD-015 (Royal Canin $1,200) | Cantidad: 2  → subtotal $2,400");

        OrdenRequest req = OrdenRequest.newBuilder()
                .setIdCliente("CLI-003").setIdProducto("PRD-015").setCantidad(2).build();
        try {
            OrdenResponse r = stub.procesarOrden(req);
            imprimirRespuesta(r);
        } catch (StatusRuntimeException e) {
            LOG.warning("Error gRPC: " + e.getStatus());
        }
    }

    // ── Listar vacunas disponibles ────────────────────────────────────────────
    private void listarVacunas() {
        separador("CATÁLOGO — Vacunas disponibles");
        try {
            ProductoListResponse r = stub.listarProductos(
                    ProductoFiltroRequest.newBuilder().setTipo("VACUNA").build());
            LOG.info("Total vacunas: " + r.getTotal());
            r.getProductosList().forEach(p ->
                LOG.info(String.format("  %-6s | %-35s | Stock: %3d | $%.2f",
                        p.getId(), p.getNombre(), p.getStock(), p.getPrecio())));
        } catch (StatusRuntimeException e) {
            LOG.warning("Error: " + e.getStatus());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void imprimirRespuesta(OrdenResponse r) {
        LOG.info("RESULTADO  : " + r.getEstado());
        LOG.info("ID Orden   : " + r.getIdOrden());
        LOG.info(String.format("Subtotal   : $%,.2f", r.getSubtotal()));
        LOG.info(String.format("Descuento  : $%,.2f", r.getDescuento()));
        LOG.info(String.format("IVA (16%%) : $%,.2f", r.getIva()));
        LOG.info(String.format("TOTAL PAGO : $%,.2f", r.getTotalPagar()));
        if (!r.getMensajeError().isEmpty()) LOG.info("Mensaje    : " + r.getMensajeError());
    }

    private void separador(String titulo) {
        LOG.info("");
        LOG.info("════════════════════════════════════════════════════");
        LOG.info("  " + titulo);
        LOG.info("════════════════════════════════════════════════════");
    }

    // ── main ──────────────────────────────────────────────────────────────────
    public static void main(String[] args) throws InterruptedException {
        HuellitasClientTest client = new HuellitasClientTest("localhost", 50051);

        LOG.info("╔══════════════════════════════════════════════════╗");
        LOG.info("║    HUELLITAS  —  PRUEBAS DE INTEGRACIÓN gRPC     ║");
        LOG.info("╚══════════════════════════════════════════════════╝");

        try {
            client.listarVacunas();
            client.casoOrdenValida();
            client.casoSobreGiroStock();
            client.casoDatosInvalidos();
            client.casoConDescuento();
        } finally {
            client.shutdown();
        }

        LOG.info("");
        LOG.info("════ PRUEBAS FINALIZADAS ════");
    }
}
