package com.huellitas;

import com.huellitas.domain.service.OrdenService;
import com.huellitas.infrastructure.db.DatabaseManager;
import com.huellitas.infrastructure.grpc.OrdenGrpcServiceImpl;
import com.huellitas.infrastructure.repository.*;
import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class HuellitasServer {

    private static final Logger LOG  = Logger.getLogger(HuellitasServer.class.getName());
    private static final int    PORT = 50051;

    private Server server;

    public void start() throws IOException {
        DatabaseManager.getInstance();

        ProductoRepositoryImpl productoRepo = new ProductoRepositoryImpl();
        ClienteRepositoryImpl  clienteRepo  = new ClienteRepositoryImpl();
        OrdenRepositoryImpl    ordenRepo    = new OrdenRepositoryImpl();

        OrdenService          service     = new OrdenService(productoRepo, clienteRepo, ordenRepo);
        OrdenGrpcServiceImpl  grpcService = new OrdenGrpcServiceImpl(service, productoRepo);

        server = ServerBuilder.forPort(PORT)
                .addService(grpcService)
                .build()
                .start();

        LOG.info("╔══════════════════════════════════════════════════╗");
        LOG.info("║   HUELLITAS  —  Servidor gRPC iniciado           ║");
        LOG.info("║   Puerto  : " + PORT + "                                  ║");
        LOG.info("║   DB      : huellitas.db (SQLite)                ║");
        LOG.info("╚══════════════════════════════════════════════════╝");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOG.warning("Apagando servidor...");
            try { stop(); } catch (InterruptedException e) { e.printStackTrace(System.err); }
        }));
    }

    public void stop() throws InterruptedException {
        if (server != null) server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
    }

    public void blockUntilShutdown() throws InterruptedException {
        if (server != null) server.awaitTermination();
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        HuellitasServer srv = new HuellitasServer();
        srv.start();
        srv.blockUntilShutdown();
    }
}
