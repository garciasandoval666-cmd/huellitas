package com.huellitas.domain.model;

public class Cliente {
    private String id;
    private String nombre;
    private String email;
    private String telefono;
    private String tipoMascota;

    public Cliente(String id, String nombre, String email, String telefono, String tipoMascota) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.tipoMascota = tipoMascota;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public String getTelefono() { return telefono; }
    public String getTipoMascota() { return tipoMascota; }
}
