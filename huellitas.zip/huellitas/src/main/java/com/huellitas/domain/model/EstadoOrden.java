package com.huellitas.domain.model;

public enum EstadoOrden {
    CREADA,
    VALIDADA,
    APROBADA,
    RECHAZADA
}
