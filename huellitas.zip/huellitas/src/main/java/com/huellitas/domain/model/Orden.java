package com.huellitas.domain.model;

import java.time.LocalDateTime;

public class Orden {
    private String id;
    private String idCliente;
    private String idProducto;
    private int cantidad;
    private EstadoOrden estado;
    private double subtotal;
    private double descuento;
    private double iva;
    private double totalPagar;
    private String mensaje;
    private LocalDateTime fechaCreacion;

    public Orden(String id, String idCliente, String idProducto, int cantidad) {
        this.id = id;
        this.idCliente = idCliente;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.estado = EstadoOrden.CREADA;
        this.fechaCreacion = LocalDateTime.now();
    }

    public Orden(String id, String idCliente, String idProducto, int cantidad,
                 EstadoOrden estado, double subtotal, double descuento,
                 double iva, double totalPagar, String mensaje) {
        this.id = id;
        this.idCliente = idCliente;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.estado = estado;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.iva = iva;
        this.totalPagar = totalPagar;
        this.mensaje = mensaje;
        this.fechaCreacion = LocalDateTime.now();
    }

    public String getId() { return id; }
    public String getIdCliente() { return idCliente; }
    public String getIdProducto() { return idProducto; }
    public int getCantidad() { return cantidad; }
    public EstadoOrden getEstado() { return estado; }
    public void setEstado(EstadoOrden estado) { this.estado = estado; }
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    public double getDescuento() { return descuento; }
    public void setDescuento(double descuento) { this.descuento = descuento; }
    public double getIva() { return iva; }
    public void setIva(double iva) { this.iva = iva; }
    public double getTotalPagar() { return totalPagar; }
    public void setTotalPagar(double totalPagar) { this.totalPagar = totalPagar; }
    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }
    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
}
