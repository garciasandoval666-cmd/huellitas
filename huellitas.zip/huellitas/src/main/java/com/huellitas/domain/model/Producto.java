package com.huellitas.domain.model;

public class Producto {
    private String id;
    private String nombre;
    private TipoProducto tipo;
    private double precio;
    private int stock;
    private String descripcion;
    private String marca;

    public Producto(String id, String nombre, TipoProducto tipo,
                    double precio, int stock, String descripcion, String marca) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.stock = stock;
        this.descripcion = descripcion;
        this.marca = marca;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public TipoProducto getTipo() { return tipo; }
    public double getPrecio() { return precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public String getDescripcion() { return descripcion; }
    public String getMarca() { return marca; }
}
