package com.huellitas.domain.model;

public enum TipoProducto {
    VACUNA,
    MEDICAMENTO,
    ALIMENTO
}
