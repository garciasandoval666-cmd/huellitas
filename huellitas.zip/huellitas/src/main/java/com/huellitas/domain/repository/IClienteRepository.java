package com.huellitas.domain.repository;

import com.huellitas.domain.model.Cliente;
import java.util.List;
import java.util.Optional;

public interface IClienteRepository {
    Optional<Cliente> findById(String id);
    List<Cliente> findAll();
}
