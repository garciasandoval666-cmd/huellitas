package com.huellitas.domain.repository;

import com.huellitas.domain.model.Orden;
import java.util.List;
import java.util.Optional;

public interface IOrdenRepository {
    void guardar(Orden orden);
    Optional<Orden> findById(String id);
    List<Orden> findAll();
}
