package com.huellitas.domain.repository;

import com.huellitas.domain.model.Producto;
import com.huellitas.domain.model.TipoProducto;
import java.util.List;
import java.util.Optional;

public interface IProductoRepository {
    Optional<Producto> findById(String id);
    List<Producto> findAll();
    List<Producto> findByTipo(TipoProducto tipo);
    void actualizarStock(String id, int nuevoStock);
}
