package com.huellitas.domain.service;

import com.huellitas.domain.model.*;
import com.huellitas.domain.repository.*;

import java.util.UUID;

/**
 * Capa de negocio pura. No conoce gRPC, HTTP ni ningún transporte.
 * Implementa las 3 reglas: validación de stock, cálculo de IVA/descuento
 * y transición de estados CREADA -> VALIDADA -> APROBADA/RECHAZADA.
 */
public class OrdenService {

    private static final double IVA_RATE         = 0.16;
    private static final double DESCUENTO_RATE   = 0.10;
    private static final double UMBRAL_DESCUENTO = 1_500.00;

    private final IProductoRepository productoRepo;
    private final IClienteRepository  clienteRepo;
    private final IOrdenRepository    ordenRepo;

    public OrdenService(IProductoRepository productoRepo,
                        IClienteRepository  clienteRepo,
                        IOrdenRepository    ordenRepo) {
        this.productoRepo = productoRepo;
        this.clienteRepo  = clienteRepo;
        this.ordenRepo    = ordenRepo;
    }

    public Orden procesarOrden(String idCliente, String idProducto, int cantidad) {
        // --- validaciones de entrada (lanzadas antes de crear la orden) ---
        if (idCliente == null || idCliente.isBlank())
            throw new IllegalArgumentException("El ID de cliente no puede estar vacío");
        if (idProducto == null || idProducto.isBlank())
            throw new IllegalArgumentException("El ID de producto no puede estar vacío");
        if (cantidad <= 0)
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");

        clienteRepo.findById(idCliente)
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado: " + idCliente));

        Producto producto = productoRepo.findById(idProducto)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado: " + idProducto));

        String id = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        // Estado inicial obligatorio: CREADA
        Orden orden = new Orden(id, idCliente, idProducto, cantidad);

        // Transición a VALIDADA — Regla 1: stock
        orden.setEstado(EstadoOrden.VALIDADA);

        if (producto.getStock() < cantidad) {
            orden.setEstado(EstadoOrden.RECHAZADA);
            orden.setMensaje(String.format(
                    "Stock insuficiente. Solicitado: %d, Disponible: %d",
                    cantidad, producto.getStock()));
            ordenRepo.guardar(orden);
            return orden;
        }

        // Regla 2: cálculo de impuestos y descuento
        double subtotal      = producto.getPrecio() * cantidad;
        double descuento     = subtotal > UMBRAL_DESCUENTO ? subtotal * DESCUENTO_RATE : 0.0;
        double baseImponible = subtotal - descuento;
        double iva           = baseImponible * IVA_RATE;
        double totalPagar    = baseImponible + iva;

        orden.setSubtotal(subtotal);
        orden.setDescuento(descuento);
        orden.setIva(iva);
        orden.setTotalPagar(totalPagar);

        // Transición final a APROBADA
        orden.setEstado(EstadoOrden.APROBADA);
        orden.setMensaje("Orden procesada exitosamente");

        productoRepo.actualizarStock(idProducto, producto.getStock() - cantidad);
        ordenRepo.guardar(orden);
        return orden;
    }

    public Orden consultarOrden(String idOrden) {
        return ordenRepo.findById(idOrden)
                .orElseThrow(() -> new IllegalArgumentException("Orden no encontrada: " + idOrden));
    }
}
