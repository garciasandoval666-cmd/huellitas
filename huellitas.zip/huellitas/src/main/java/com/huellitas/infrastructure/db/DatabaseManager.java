package com.huellitas.infrastructure.db;

import java.sql.*;
import java.util.logging.Logger;

public class DatabaseManager {

    private static final Logger LOG    = Logger.getLogger(DatabaseManager.class.getName());
    private static final String DB_URL = "jdbc:sqlite:huellitas.db";

    private static DatabaseManager instance;
    private Connection connection;

    private DatabaseManager() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(DB_URL);
            createTables();
            seedData();
            LOG.info("Base de datos Huellitas inicializada correctamente.");
        } catch (Exception e) {
            throw new RuntimeException("Error al inicializar la base de datos", e);
        }
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) instance = new DatabaseManager();
        return instance;
    }

    public Connection getConnection() { return connection; }

    // ─────────────────────────────────────────────────────────────────────────
    // DDL
    // ─────────────────────────────────────────────────────────────────────────
    private void createTables() throws SQLException {
        String[] ddl = {
            "CREATE TABLE IF NOT EXISTS clientes (" +
            "  id TEXT PRIMARY KEY," +
            "  nombre TEXT NOT NULL," +
            "  email TEXT," +
            "  telefono TEXT," +
            "  tipo_mascota TEXT" +
            ")",

            "CREATE TABLE IF NOT EXISTS productos (" +
            "  id TEXT PRIMARY KEY," +
            "  nombre TEXT NOT NULL," +
            "  tipo TEXT NOT NULL," +
            "  precio REAL NOT NULL," +
            "  stock INTEGER NOT NULL," +
            "  descripcion TEXT," +
            "  marca TEXT" +
            ")",

            "CREATE TABLE IF NOT EXISTS ordenes (" +
            "  id TEXT PRIMARY KEY," +
            "  id_cliente TEXT NOT NULL," +
            "  id_producto TEXT NOT NULL," +
            "  cantidad INTEGER NOT NULL," +
            "  estado TEXT NOT NULL," +
            "  subtotal REAL DEFAULT 0," +
            "  descuento REAL DEFAULT 0," +
            "  iva REAL DEFAULT 0," +
            "  total_pagar REAL DEFAULT 0," +
            "  mensaje TEXT," +
            "  fecha_creacion TEXT," +
            "  FOREIGN KEY (id_cliente)  REFERENCES clientes(id)," +
            "  FOREIGN KEY (id_producto) REFERENCES productos(id)" +
            ")"
        };
        try (Statement st = connection.createStatement()) {
            for (String sql : ddl) st.execute(sql);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SEED
    // ─────────────────────────────────────────────────────────────────────────
    private void seedData() throws SQLException {
        if (isSeeded()) return;
        seedClientes();
        seedProductos();
        seedOrdenes();
        LOG.info("Datos iniciales (20 registros por tabla) cargados.");
    }

    private boolean isSeeded() throws SQLException {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM clientes")) {
            return rs.getInt(1) > 0;
        }
    }

    // ── 20 CLIENTES ──────────────────────────────────────────────────────────
    private void seedClientes() throws SQLException {
        String sql = "INSERT INTO clientes (id, nombre, email, telefono, tipo_mascota) VALUES (?,?,?,?,?)";
        Object[][] data = {
            {"CLI-001","Ana García López","ana.garcia@email.com","555-0101","Perro"},
            {"CLI-002","Carlos Martínez Ruiz","carlos.m@email.com","555-0102","Gato"},
            {"CLI-003","María Hernández Cruz","maria.h@email.com","555-0103","Perro"},
            {"CLI-004","José Rodríguez Díaz","jose.r@email.com","555-0104","Gato"},
            {"CLI-005","Laura Pérez Sánchez","laura.p@email.com","555-0105","Perro"},
            {"CLI-006","Miguel Torres Flores","miguel.t@email.com","555-0106","Conejo"},
            {"CLI-007","Sofía Ramírez Castro","sofia.r@email.com","555-0107","Gato"},
            {"CLI-008","Diego Morales Vega","diego.m@email.com","555-0108","Perro"},
            {"CLI-009","Valentina Jiménez Mora","valentina.j@email.com","555-0109","Gato"},
            {"CLI-010","Roberto Vargas Núñez","roberto.v@email.com","555-0110","Perro"},
            {"CLI-011","Isabella López Torres","isabella.l@email.com","555-0111","Gato"},
            {"CLI-012","Fernando Gutiérrez Ríos","fernando.g@email.com","555-0112","Perro"},
            {"CLI-013","Camila Mendoza Ortiz","camila.m@email.com","555-0113","Hamster"},
            {"CLI-014","Alejandro Cruz Reyes","alejandro.c@email.com","555-0114","Perro"},
            {"CLI-015","Natalia Soto Aguilar","natalia.s@email.com","555-0115","Gato"},
            {"CLI-016","Daniel Romero Cabrera","daniel.r@email.com","555-0116","Perro"},
            {"CLI-017","Valeria Herrera Campos","valeria.h@email.com","555-0117","Gato"},
            {"CLI-018","Sebastián Medina Lara","sebastian.m@email.com","555-0118","Perro"},
            {"CLI-019","Gabriela Ramos Peña","gabriela.r@email.com","555-0119","Conejo"},
            {"CLI-020","Andrés Castillo Fuentes","andres.c@email.com","555-0120","Perro"}
        };
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            for (Object[] row : data) {
                ps.setString(1,(String)row[0]); ps.setString(2,(String)row[1]);
                ps.setString(3,(String)row[2]); ps.setString(4,(String)row[3]);
                ps.setString(5,(String)row[4]);
                ps.executeUpdate();
            }
        }
    }

    // ── 20 PRODUCTOS (7 vacunas · 7 medicamentos · 6 alimentos) ─────────────
    private void seedProductos() throws SQLException {
        String sql = "INSERT INTO productos (id,nombre,tipo,precio,stock,descripcion,marca) VALUES (?,?,?,?,?,?,?)";
        Object[][] data = {
            // VACUNAS
            {"PRD-001","Vacuna Antirrábica Canina","VACUNA",250.00,150,"Vacuna contra la rabia para perros","Pfizer Vet"},
            {"PRD-002","Vacuna DHPP (Distemper)","VACUNA",320.00,120,"Vacuna cuádruple canina","Nobivac"},
            {"PRD-003","Vacuna Bordetella","VACUNA",280.00,80,"Vacuna contra la tos de las perreras","Bronchicine"},
            {"PRD-004","Vacuna Leptospirosis","VACUNA",310.00,100,"Protección contra leptospirosis","Nobivac Lepto"},
            {"PRD-005","Vacuna Antirrábica Felina","VACUNA",230.00,130,"Vacuna contra la rabia para gatos","Purevax"},
            {"PRD-006","Vacuna Triple Felina","VACUNA",350.00,90,"Vacuna trivalente felina","Felocell"},
            {"PRD-007","Vacuna Leucemia Felina","VACUNA",400.00,70,"Protección contra leucemia viral felina","Leucorifelin"},
            // MEDICAMENTOS
            {"PRD-008","Frontline Plus Perros","MEDICAMENTO",450.00,200,"Antipulgas y garrapatas mensual","Frontline"},
            {"PRD-009","NexGard Antipulgas","MEDICAMENTO",520.00,180,"Antipulgas masticable mensual","Merial"},
            {"PRD-010","Heartgard Antiparasitario","MEDICAMENTO",380.00,160,"Antiparasitario preventivo mensual","Merial"},
            {"PRD-011","Apoquel Antialérgico","MEDICAMENTO",650.00,100,"Control de picazón en perros","Zoetis"},
            {"PRD-012","Bravecto 3 meses","MEDICAMENTO",890.00,120,"Antipulgas de larga duración","MSD Animal"},
            {"PRD-013","Drontal Plus Antiparasitario","MEDICAMENTO",180.00,250,"Antiparasitario interno amplio espectro","Bayer"},
            {"PRD-014","Milbemax Felino","MEDICAMENTO",290.00,140,"Antiparasitario para gatos","Elanco"},
            // ALIMENTOS
            {"PRD-015","Royal Canin Adulto Grande 15kg","ALIMENTO",1200.00,50,"Alimento premium para razas grandes","Royal Canin"},
            {"PRD-016","Purina Pro Plan Cachorro 7.5kg","ALIMENTO",850.00,80,"Alimento para cachorros de alta energía","Purina"},
            {"PRD-017","Hill's Science Diet Senior 6.8kg","ALIMENTO",950.00,60,"Alimento para mascotas mayores","Hill's"},
            {"PRD-018","Eukanuba Adulto Mediano 12kg","ALIMENTO",1100.00,45,"Nutrición completa para razas medianas","Eukanuba"},
            {"PRD-019","Pedigree Adulto 15kg","ALIMENTO",650.00,100,"Alimento completo para adultos","Pedigree"},
            {"PRD-020","Whiskas Gato Adulto 7kg","ALIMENTO",480.00,90,"Alimento completo para gatos adultos","Whiskas"}
        };
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            for (Object[] row : data) {
                ps.setString(1,(String)row[0]); ps.setString(2,(String)row[1]);
                ps.setString(3,(String)row[2]); ps.setDouble(4,(Double)row[3]);
                ps.setInt(5,(Integer)row[4]);   ps.setString(6,(String)row[5]);
                ps.setString(7,(String)row[6]);
                ps.executeUpdate();
            }
        }
    }

    // ── 20 ÓRDENES históricas ─────────────────────────────────────────────────
    private void seedOrdenes() throws SQLException {
        String sql = "INSERT INTO ordenes " +
            "(id,id_cliente,id_producto,cantidad,estado,subtotal,descuento,iva,total_pagar,mensaje,fecha_creacion)" +
            " VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'))";
        // subtotal, descuento, iva, total calculados manualmente para coherencia
        Object[][] data = {
            {"ORD-0001","CLI-001","PRD-001",2,"APROBADA",   500.00,  0.00,  80.00,  580.00,"Orden procesada exitosamente"},
            {"ORD-0002","CLI-002","PRD-006",1,"APROBADA",   350.00,  0.00,  56.00,  406.00,"Orden procesada exitosamente"},
            {"ORD-0003","CLI-003","PRD-015",2,"APROBADA",  2400.00,240.00, 345.60, 2505.60,"Orden procesada exitosamente"},
            {"ORD-0004","CLI-004","PRD-005",3,"APROBADA",   690.00,  0.00, 110.40,  800.40,"Orden procesada exitosamente"},
            {"ORD-0005","CLI-005","PRD-008",1,"APROBADA",   450.00,  0.00,  72.00,  522.00,"Orden procesada exitosamente"},
            {"ORD-0006","CLI-006","PRD-013",5,"APROBADA",   900.00,  0.00, 144.00, 1044.00,"Orden procesada exitosamente"},
            {"ORD-0007","CLI-007","PRD-014",2,"APROBADA",   580.00,  0.00,  92.80,  672.80,"Orden procesada exitosamente"},
            {"ORD-0008","CLI-008","PRD-012",1,"RECHAZADA",    0.00,  0.00,   0.00,    0.00,"Stock insuficiente. Solicitado: 1, Disponible: 0"},
            {"ORD-0009","CLI-009","PRD-007",2,"APROBADA",   800.00,  0.00, 128.00,  928.00,"Orden procesada exitosamente"},
            {"ORD-0010","CLI-010","PRD-016",3,"APROBADA",  2550.00,255.00, 367.20, 2662.20,"Orden procesada exitosamente"},
            {"ORD-0011","CLI-011","PRD-011",1,"APROBADA",   650.00,  0.00, 104.00,  754.00,"Orden procesada exitosamente"},
            {"ORD-0012","CLI-012","PRD-002",4,"APROBADA",  1280.00,  0.00, 204.80, 1484.80,"Orden procesada exitosamente"},
            {"ORD-0013","CLI-013","PRD-009",2,"APROBADA",  1040.00,  0.00, 166.40, 1206.40,"Orden procesada exitosamente"},
            {"ORD-0014","CLI-014","PRD-003",1,"APROBADA",   280.00,  0.00,  44.80,  324.80,"Orden procesada exitosamente"},
            {"ORD-0015","CLI-015","PRD-020",2,"APROBADA",   960.00,  0.00, 153.60, 1113.60,"Orden procesada exitosamente"},
            {"ORD-0016","CLI-016","PRD-017",3,"APROBADA",  2850.00,285.00, 410.40, 2975.40,"Orden procesada exitosamente"},
            {"ORD-0017","CLI-017","PRD-004",2,"RECHAZADA",    0.00,  0.00,   0.00,    0.00,"Stock insuficiente. Solicitado: 200, Disponible: 0"},
            {"ORD-0018","CLI-018","PRD-010",5,"APROBADA",  1900.00,190.00, 273.60, 1983.60,"Orden procesada exitosamente"},
            {"ORD-0019","CLI-019","PRD-019",2,"APROBADA",  1300.00,  0.00, 208.00, 1508.00,"Orden procesada exitosamente"},
            {"ORD-0020","CLI-020","PRD-018",1,"APROBADA",  1100.00,  0.00, 176.00, 1276.00,"Orden procesada exitosamente"}
        };
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            for (Object[] row : data) {
                ps.setString(1,(String)row[0]);  ps.setString(2,(String)row[1]);
                ps.setString(3,(String)row[2]);  ps.setInt(4,(Integer)row[3]);
                ps.setString(5,(String)row[4]);  ps.setDouble(6,(Double)row[5]);
                ps.setDouble(7,(Double)row[6]);  ps.setDouble(8,(Double)row[7]);
                ps.setDouble(9,(Double)row[8]);  ps.setString(10,(String)row[9]);
                ps.executeUpdate();
            }
        }
    }
}
