package com.huellitas.infrastructure.grpc;

import com.huellitas.domain.model.Orden;
import com.huellitas.domain.model.Producto;
import com.huellitas.domain.model.TipoProducto;
import com.huellitas.domain.repository.IProductoRepository;
import com.huellitas.domain.service.OrdenService;
import com.huellitas.grpc.*;

import io.grpc.Status;
import io.grpc.stub.StreamObserver;

import java.util.List;
import java.util.logging.Logger;

/**
 * Capa de transporte gRPC. Su única responsabilidad es serializar/deserializar
 * mensajes Protobuf, delegar a OrdenService y convertir excepciones de dominio
 * en errores gRPC controlados. No contiene ninguna regla de negocio.
 */
public class OrdenGrpcServiceImpl extends OrdenServiceGrpc.OrdenServiceImplBase {

    private static final Logger LOG = Logger.getLogger(OrdenGrpcServiceImpl.class.getName());

    private final OrdenService          ordenService;
    private final IProductoRepository   productoRepo;

    public OrdenGrpcServiceImpl(OrdenService ordenService, IProductoRepository productoRepo) {
        this.ordenService = ordenService;
        this.productoRepo = productoRepo;
    }

    // ── RPC: ProcesarOrden ───────────────────────────────────────────────────
    @Override
    public void procesarOrden(OrdenRequest req, StreamObserver<OrdenResponse> obs) {
        LOG.info(String.format("[gRPC] ProcesarOrden  cliente=%s  producto=%s  cantidad=%d",
                req.getIdCliente(), req.getIdProducto(), req.getCantidad()));
        try {
            Orden orden = ordenService.procesarOrden(
                    req.getIdCliente(), req.getIdProducto(), req.getCantidad());

            obs.onNext(toResponse(orden));
            obs.onCompleted();

        } catch (IllegalArgumentException e) {
            LOG.warning("[gRPC] Argumento inválido: " + e.getMessage());
            obs.onError(Status.INVALID_ARGUMENT.withDescription(e.getMessage()).asRuntimeException());
        } catch (Exception e) {
            LOG.severe("[gRPC] Error interno: " + e.getMessage());
            obs.onError(Status.INTERNAL.withDescription("Error interno: " + e.getMessage()).asRuntimeException());
        }
    }

    // ── RPC: ConsultarOrden ──────────────────────────────────────────────────
    @Override
    public void consultarOrden(ConsultaRequest req, StreamObserver<OrdenResponse> obs) {
        LOG.info("[gRPC] ConsultarOrden  id=" + req.getIdOrden());
        try {
            Orden orden = ordenService.consultarOrden(req.getIdOrden());
            obs.onNext(toResponse(orden));
            obs.onCompleted();
        } catch (IllegalArgumentException e) {
            obs.onError(Status.NOT_FOUND.withDescription(e.getMessage()).asRuntimeException());
        } catch (Exception e) {
            obs.onError(Status.INTERNAL.withDescription("Error interno: " + e.getMessage()).asRuntimeException());
        }
    }

    // ── RPC: ListarProductos ─────────────────────────────────────────────────
    @Override
    public void listarProductos(ProductoFiltroRequest req, StreamObserver<ProductoListResponse> obs) {
        try {
            List<Producto> productos = req.getTipo().isEmpty()
                    ? productoRepo.findAll()
                    : productoRepo.findByTipo(TipoProducto.valueOf(req.getTipo().toUpperCase()));

            ProductoListResponse.Builder builder = ProductoListResponse.newBuilder();
            for (Producto p : productos) {
                builder.addProductos(ProductoInfo.newBuilder()
                        .setId(p.getId())
                        .setNombre(p.getNombre())
                        .setTipo(p.getTipo().name())
                        .setPrecio(p.getPrecio())
                        .setStock(p.getStock())
                        .setDescripcion(p.getDescripcion() != null ? p.getDescripcion() : "")
                        .setMarca(p.getMarca() != null ? p.getMarca() : "")
                        .build());
            }
            builder.setTotal(productos.size());
            obs.onNext(builder.build());
            obs.onCompleted();

        } catch (IllegalArgumentException e) {
            obs.onError(Status.INVALID_ARGUMENT
                    .withDescription("Tipo inválido: " + req.getTipo()).asRuntimeException());
        }
    }

    // ── RPC: ConsultarStock ──────────────────────────────────────────────────
    @Override
    public void consultarStock(StockRequest req, StreamObserver<StockResponse> obs) {
        try {
            Producto p = productoRepo.findById(req.getIdProducto())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Producto no encontrado: " + req.getIdProducto()));

            obs.onNext(StockResponse.newBuilder()
                    .setIdProducto(p.getId())
                    .setNombre(p.getNombre())
                    .setStockDisponible(p.getStock())
                    .setDisponible(p.getStock() > 0)
                    .build());
            obs.onCompleted();

        } catch (IllegalArgumentException e) {
            obs.onError(Status.NOT_FOUND.withDescription(e.getMessage()).asRuntimeException());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private OrdenResponse toResponse(Orden o) {
        return OrdenResponse.newBuilder()
                .setIdOrden(o.getId())
                .setEstado(o.getEstado().name())
                .setSubtotal(o.getSubtotal())
                .setDescuento(o.getDescuento())
                .setIva(o.getIva())
                .setTotalPagar(o.getTotalPagar())
                .setMensajeError(o.getMensaje() != null ? o.getMensaje() : "")
                .build();
    }
}
