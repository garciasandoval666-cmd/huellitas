package com.huellitas.infrastructure.repository;

import com.huellitas.domain.model.Cliente;
import com.huellitas.domain.repository.IClienteRepository;
import com.huellitas.infrastructure.db.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ClienteRepositoryImpl implements IClienteRepository {

    private Connection conn() { return DatabaseManager.getInstance().getConnection(); }

    @Override
    public Optional<Cliente> findById(String id) {
        try (PreparedStatement ps = conn().prepareStatement("SELECT * FROM clientes WHERE id = ?")) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar cliente: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Cliente> findAll() {
        List<Cliente> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM clientes ORDER BY nombre")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar clientes", e);
        }
        return list;
    }

    private Cliente map(ResultSet rs) throws SQLException {
        return new Cliente(
            rs.getString("id"),
            rs.getString("nombre"),
            rs.getString("email"),
            rs.getString("telefono"),
            rs.getString("tipo_mascota")
        );
    }
}
