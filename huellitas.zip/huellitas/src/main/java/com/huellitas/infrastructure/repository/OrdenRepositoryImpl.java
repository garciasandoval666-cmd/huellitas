package com.huellitas.infrastructure.repository;

import com.huellitas.domain.model.EstadoOrden;
import com.huellitas.domain.model.Orden;
import com.huellitas.domain.repository.IOrdenRepository;
import com.huellitas.infrastructure.db.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OrdenRepositoryImpl implements IOrdenRepository {

    private Connection conn() { return DatabaseManager.getInstance().getConnection(); }

    @Override
    public void guardar(Orden orden) {
        String sql = "INSERT OR REPLACE INTO ordenes " +
            "(id,id_cliente,id_producto,cantidad,estado,subtotal,descuento,iva,total_pagar,mensaje,fecha_creacion)" +
            " VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'))";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, orden.getId());
            ps.setString(2, orden.getIdCliente());
            ps.setString(3, orden.getIdProducto());
            ps.setInt(4, orden.getCantidad());
            ps.setString(5, orden.getEstado().name());
            ps.setDouble(6, orden.getSubtotal());
            ps.setDouble(7, orden.getDescuento());
            ps.setDouble(8, orden.getIva());
            ps.setDouble(9, orden.getTotalPagar());
            ps.setString(10, orden.getMensaje());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al guardar orden: " + orden.getId(), e);
        }
    }

    @Override
    public Optional<Orden> findById(String id) {
        try (PreparedStatement ps = conn().prepareStatement("SELECT * FROM ordenes WHERE id = ?")) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar orden: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Orden> findAll() {
        List<Orden> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM ordenes ORDER BY fecha_creacion DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar órdenes", e);
        }
        return list;
    }

    private Orden map(ResultSet rs) throws SQLException {
        return new Orden(
            rs.getString("id"),
            rs.getString("id_cliente"),
            rs.getString("id_producto"),
            rs.getInt("cantidad"),
            EstadoOrden.valueOf(rs.getString("estado")),
            rs.getDouble("subtotal"),
            rs.getDouble("descuento"),
            rs.getDouble("iva"),
            rs.getDouble("total_pagar"),
            rs.getString("mensaje")
        );
    }
}
