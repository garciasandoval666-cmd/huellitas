package com.huellitas.infrastructure.repository;

import com.huellitas.domain.model.Producto;
import com.huellitas.domain.model.TipoProducto;
import com.huellitas.domain.repository.IProductoRepository;
import com.huellitas.infrastructure.db.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductoRepositoryImpl implements IProductoRepository {

    private Connection conn() { return DatabaseManager.getInstance().getConnection(); }

    @Override
    public Optional<Producto> findById(String id) {
        try (PreparedStatement ps = conn().prepareStatement("SELECT * FROM productos WHERE id = ?")) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar producto: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Producto> findAll() {
        List<Producto> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM productos ORDER BY tipo, nombre")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar productos", e);
        }
        return list;
    }

    @Override
    public List<Producto> findByTipo(TipoProducto tipo) {
        List<Producto> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(
                "SELECT * FROM productos WHERE tipo = ? ORDER BY nombre")) {
            ps.setString(1, tipo.name());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al filtrar productos por tipo", e);
        }
        return list;
    }

    @Override
    public void actualizarStock(String id, int nuevoStock) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE productos SET stock = ? WHERE id = ?")) {
            ps.setInt(1, nuevoStock);
            ps.setString(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar stock del producto: " + id, e);
        }
    }

    private Producto map(ResultSet rs) throws SQLException {
        return new Producto(
            rs.getString("id"),
            rs.getString("nombre"),
            TipoProducto.valueOf(rs.getString("tipo")),
            rs.getDouble("precio"),
            rs.getInt("stock"),
            rs.getString("descripcion"),
            rs.getString("marca")
        );
    }
}
